<?php 
$json=file_get_contents("php://input");
$data=json_decode($json,TRUE);
if(isset($data["activity_message"]))    
    {
    session_start();
    addParcxUserActivity($data["activity_message"],$_SESSION["user"],$_SESSION['userId'],$json);      
    }
$response=parcxV2UserManagement($data);
if(is_array($response))
    {    
    if($data["task"]==12)
        {        
        if($response["message"]=="Success")
            {
            session_start();
            $_SESSION['user'] = $response["operator_name"];
            $_SESSION['userRollName'] = $response["user_role_name"];
            $_SESSION['userRollId'] = $response["user_role_id"]; 
            $_SESSION['userId'] = $response["user_id"];            
            $_SESSION["language"] = ucfirst($response["language"]) ;               
            $_SESSION['last_login_timestamp'] = time(); 
            
            addParcxUserActivity("Login",$_SESSION["user"],$_SESSION['userId'],json_encode($response));    
            }
        echo $response["message"];
        }
    else 
        echo json_encode($response);
    }
else
    echo $response;
?>
