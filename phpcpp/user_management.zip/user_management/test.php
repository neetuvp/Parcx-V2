<?php            	        
$json='{"id":"","activity_message":"Add user test@gmail.com","generate_pwd":0,"reset_pwd":0,"full_name":"Neetu","user_name":"test@gmail.com","email":"npillai@alfalakme.com","password":"Parcx123!","company_name":"Al Falak Middle East LLC Dubai","phone":"04567894","start_date":"2021-11-22","expiry_date":"2021-12-22","user_role":"105","language":"English","task":"7"}';
$data = json_decode($json,true);
$r=parcxV2UserManagement($data);
if(is_array($r))
print_r($r);
else
echo $r;
             

?>
